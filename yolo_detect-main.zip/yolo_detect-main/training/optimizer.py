# training/optimizer.py
import torch.optim as optim

def get_optimizer(model, config):
    if config['optimizer'] == 'Adam':
        return optim.Adam(model.parameters(), lr=config['lr'], weight_decay=config['weight_decay'])
    return optim.SGD(model.parameters(), lr=config['lr'], momentum=0.9)