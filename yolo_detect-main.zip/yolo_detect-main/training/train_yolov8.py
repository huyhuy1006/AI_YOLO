# train_yolov8.py
from ultralytics import YOLO

def main():
    # Load YOLOv8n model with pre-trained weights
    model = YOLO('yolov8n.pt')  # Download from Ultralytics if not already present

    # Train the model
    model.train(
        data='configs/data.yaml',  # Path to dataset config
        epochs=50,               # Number of epochs
        batch=4,                  # Batch size (suitable for GTX 1050 Ti)
        imgsz=416,                # Image size (matches your setup)
        device=0,                 # Use GPU (0 for first GPU)
        patience=50,              # Early stopping if no improvement
        project='outputs/yolov8', # Save results
        name='yolov8n_car',       # Experiment name
        pretrained=True,          # Use pre-trained weights
        optimizer='Adam',         # Matches your previous setup
        lr0=0.001,                # Initial learning rate
        weight_decay=0.0005,      # Matches your previous setup
        augment=True              # Enable data augmentation
    )

if __name__ == '__main__':
    main()