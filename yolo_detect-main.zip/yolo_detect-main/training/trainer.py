# training/trainer.py
import torch
from torch.utils.data import DataLoader
from datasets.dataset import YOLODataset
from datasets.transforms import YOLOTransforms
from models.detector import Detector
from models.loss import YOLOLoss
import os
from utils.logger import setup_logger

def collate_fn(batch):
    batch = [b for b in batch if b is not None]
    if not batch:
        return torch.empty(0), torch.empty((0, 6), dtype=torch.float32)
    
    imgs, boxes_list, labels_list = zip(*batch)
    imgs = torch.stack([torch.from_numpy(img).permute(2, 0, 1).float() for img in imgs])
    targets = []
    for i, (boxes, labels) in enumerate(zip(boxes_list, labels_list)):
        if len(boxes) > 0:
            batch_idx = torch.full((len(boxes), 1), i, dtype=torch.float32)
            boxes = torch.from_numpy(boxes).float()
            labels = torch.from_numpy(labels).float().reshape(-1, 1)
            target = torch.cat([batch_idx, labels, boxes], dim=1)
            targets.append(target)
    if len(targets) > 0:
        targets = torch.cat(targets, dim=0)
    else:
        targets = torch.empty((0, 6), dtype=torch.float32)
    return imgs, targets

def sparse_to_dense_targets(targets, batch_size, grid_size, num_anchors, num_classes):
    dense_targets = torch.zeros(batch_size, num_anchors, grid_size, grid_size, 5 + num_classes)
    if targets.shape[0] == 0:
        return dense_targets

    for target in targets:
        batch_idx, class_id, x_center, y_center, width, height = target
        batch_idx = int(batch_idx.item())
        class_id = int(class_id.item())
        grid_x = int(x_center * grid_size)
        grid_y = int(y_center * grid_size)
        anchor_idx = 0  # Single anchor
        dense_targets[batch_idx, anchor_idx, grid_y, grid_x, 0:4] = torch.tensor([x_center, y_center, width, height])
        dense_targets[batch_idx, anchor_idx, grid_y, grid_x, 4] = 1.0
        dense_targets[batch_idx, anchor_idx, grid_y, grid_x, 5 + class_id] = 1.0
    return dense_targets

class Trainer:
    def __init__(self, model_config, data_config, train_config):
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        print(f"Using device: {self.device}")
        self.model = Detector(num_classes=data_config['nc']).to(self.device)
        self.loss_fn = YOLOLoss(num_classes=data_config['nc'])
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=train_config['lr'])
        self.train_dataset = YOLODataset(
            data_dir=data_config['train'],
            data_config=data_config,
            transform=YOLOTransforms(train_config['img_size'])
        )
        self.train_loader = DataLoader(
            self.train_dataset,
            batch_size=train_config['batch_size'],
            shuffle=True,
            collate_fn=collate_fn
        )
        self.grid_size = 52  # Updated to match backbone output (416/8)
        self.num_anchors = 1  # Based on head_yolo.py
        self.num_classes = data_config['nc']
        # Setup output directories and logger
        self.save_dir = os.path.join('outputs')
        self.ckpt_dir = os.path.join(self.save_dir, 'checkpoints')
        os.makedirs(self.ckpt_dir, exist_ok=True)
        self.logger = setup_logger(os.path.join(self.save_dir, 'train.log'))
        self.logger.info(f"Device: {self.device}")
        self.logger.info(f"Optimizer: Adam, lr={train_config['lr']}")
        self.best_epoch_loss = float('inf')

    def train(self, epochs):
        self.model.train()
        for epoch in range(epochs):
            epoch_loss_sum = 0.0
            num_batches = 0
            for i, (imgs, targets) in enumerate(self.train_loader):
                imgs = imgs.to(self.device)
                targets = sparse_to_dense_targets(
                    targets,
                    batch_size=imgs.shape[0],
                    grid_size=self.grid_size,
                    num_anchors=self.num_anchors,
                    num_classes=self.num_classes
                ).to(self.device)
                print(f"Batch {i+1}: imgs on {imgs.device}, targets on {targets.device}")  # Log tensor devices
                self.optimizer.zero_grad()
                preds = self.model(imgs)
                loss = self.loss_fn(preds, targets)
                loss.backward()
                self.optimizer.step()
                batch_loss = loss.item()
                epoch_loss_sum += batch_loss
                num_batches += 1
                print(f"Epoch {epoch+1}, Batch {i+1}, Loss: {batch_loss}")
                self.logger.info(f"epoch={epoch+1} batch={i+1} loss={batch_loss:.6f}")
            if num_batches > 0:
                epoch_avg_loss = epoch_loss_sum / num_batches
            else:
                epoch_avg_loss = 0.0
            print(f"Epoch {epoch+1} Average Loss: {epoch_avg_loss:.6f}")
            self.logger.info(f"epoch={epoch+1} avg_loss={epoch_avg_loss:.6f}")
            # Save checkpoints
            last_ckpt_path = os.path.join(self.ckpt_dir, 'last.pt')
            torch.save({'model': self.model.state_dict(),
                        'optimizer': self.optimizer.state_dict(),
                        'epoch': epoch + 1,
                        'avg_loss': epoch_avg_loss}, last_ckpt_path)
            if epoch_avg_loss < self.best_epoch_loss:
                self.best_epoch_loss = epoch_avg_loss
                best_ckpt_path = os.path.join(self.ckpt_dir, 'best.pt')
                torch.save({'model': self.model.state_dict(),
                            'optimizer': self.optimizer.state_dict(),
                            'epoch': epoch + 1,
                            'avg_loss': epoch_avg_loss}, best_ckpt_path)
                self.logger.info(f"New best model saved at epoch {epoch+1} with avg_loss={epoch_avg_loss:.6f}")