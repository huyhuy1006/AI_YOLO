# training/hooks.py
import torch
import os

class CheckpointHook:
    def __init__(self, save_dir):
        self.save_dir = save_dir
        os.makedirs(save_dir, exist_ok=True)

    def save_checkpoint(self, model, epoch):
        torch.save(model.state_dict(), os.path.join(self.save_dir, f'model_epoch_{epoch}.pth'))