# evaluation/evaluator.py
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from datasets.dataset import YOLODataset
from datasets.transforms import YOLOTransforms
from models.loss import YOLOLoss
from torchmetrics.detection.mean_ap import MeanAveragePrecision

def collate_fn(batch):
    batch = [b for b in batch if b is not None]
    if not batch:
        return torch.empty(0), torch.empty((0, 6), dtype=torch.float32)
    
    imgs, boxes_list, labels_list = zip(*batch)
    imgs = torch.stack([torch.from_numpy(img).permute(2, 0, 1).float() for img in imgs])
    targets = []
    for i, (boxes, labels) in enumerate(zip(boxes_list, labels_list)):
        if len(boxes) > 0:
            batch_idx = torch.full((len(boxes), 1), i, dtype=torch.float32)
            boxes = torch.from_numpy(boxes).float()
            labels = torch.from_numpy(labels).float().reshape(-1, 1)
            target = torch.cat([batch_idx, labels, boxes], dim=1)
            targets.append(target)
    if len(targets) > 0:
        targets = torch.cat(targets, dim=0)
    else:
        targets = torch.empty((0, 6), dtype=torch.float32)
    return imgs, targets

def sparse_to_dense_targets(targets, batch_size, grid_size, num_anchors, num_classes):
    dense_targets = torch.zeros(batch_size, num_anchors, grid_size, grid_size, 5 + num_classes)
    if targets.shape[0] == 0:
        return dense_targets
    for target in targets:
        batch_idx, class_id, x_center, y_center, width, height = target
        batch_idx = int(batch_idx.item())
        class_id = int(class_id.item())
        grid_x = int(x_center * grid_size)
        grid_y = int(y_center * grid_size)
        anchor_idx = 0
        dense_targets[batch_idx, anchor_idx, grid_y, grid_x, 0:4] = torch.tensor([x_center, y_center, width, height])
        dense_targets[batch_idx, anchor_idx, grid_y, grid_x, 4] = 1.0
        dense_targets[batch_idx, anchor_idx, grid_y, grid_x, 5 + class_id] = 1.0
    return dense_targets

def non_max_suppression(boxes, scores, iou_threshold=0.5, max_detections=100):
    """Apply non-maximum suppression to filter overlapping boxes."""
    if boxes.shape[0] == 0:
        return boxes, scores
    keep = torch.ops.torchvision.nms(boxes, scores, iou_threshold)
    keep = keep[:max_detections]
    return boxes[keep], scores[keep]

class Evaluator:
    def __init__(self, model, data_config, img_size):
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model = model.to(self.device)
        self.val_dataset = YOLODataset(
            data_dir=data_config['val'],
            data_config=data_config,
            transform=YOLOTransforms(img_size)
        )
        self.val_loader = DataLoader(
            self.val_dataset,
            batch_size=4,
            shuffle=False,
            collate_fn=collate_fn
        )
        self.grid_size = 52
        self.num_anchors = 1
        self.num_classes = data_config['nc']
        self.loss_fn = YOLOLoss(num_classes=self.num_classes, num_anchors=self.num_anchors)

    def evaluate(self):
        self.model.eval()
        metric = MeanAveragePrecision()  # Remove max_detection_threshold
        total_loss = 0.0
        with torch.no_grad():
            for imgs, targets in self.val_loader:
                imgs = imgs.to(self.device)
                targets_dense = sparse_to_dense_targets(
                    targets,
                    batch_size=imgs.shape[0],
                    grid_size=self.grid_size,
                    num_anchors=self.num_anchors,
                    num_classes=self.num_classes
                ).to(self.device)
                preds = self.model(imgs)
                total_loss += self.loss_fn(preds, targets_dense).item()
                # Convert predictions to torchmetrics format
                preds_list = []
                targets_list = []
                for i in range(imgs.shape[0]):
                    pred = preds[i].view(self.num_anchors, 5 + self.num_classes, self.grid_size, self.grid_size)
                    pred = pred.permute(0, 2, 3, 1).reshape(-1, 5 + self.num_classes).to(self.device)
                    scores = torch.sigmoid(pred[:, 4])
                    boxes = pred[:, :4]
                    labels = pred[:, 5:].argmax(dim=-1).to(self.device)
                    # Apply confidence threshold and NMS
                    scores_mask = scores > 0.1  # Filter low-confidence detections
                    boxes = boxes[scores_mask]
                    scores = scores[scores_mask]
                    labels = labels[scores_mask]
                    boxes, scores = non_max_suppression(boxes, scores, iou_threshold=0.5, max_detections=100)
                    preds_list.append({
                        'boxes': boxes,
                        'scores': scores,
                        'labels': labels[:len(scores)]
                    })
                    target = targets[targets[:, 0] == i][:, 1:].to(self.device)
                    targets_list.append({
                        'boxes': target[:, 1:5],
                        'labels': target[:, 0].long()
                    })
                metric.update(preds_list, targets_list)
        
        result = metric.compute()
        avg_loss = total_loss / len(self.val_loader)
        f1 = 2 * (result['map'].item() * result['mar_1'].item()) / (result['map'].item() + result['mar_1'].item() + 1e-6)
        print(f"Validation mAP: {result['map'].item()}, mAP@0.5: {result['map_50'].item()}, "
              f"Precision: {result['map'].item()}, Recall: {result['mar_1'].item()}, F1 Score: {f1}, Val Loss: {avg_loss}")
        return result