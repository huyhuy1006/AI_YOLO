# evaluation/coco_utils.py
# (Tạm thời để đơn giản, bạn có thể dùng thư viện pycocotools để tính mAP)
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval

def compute_map(predictions, ground_truths):
    # Định dạng dữ liệu theo chuẩn COCO
    # Sử dụng pycocotools để tính mAP
    coco_gt = COCO(ground_truths)
    coco_dt = coco_gt.loadRes(predictions)
    coco_eval = COCOeval(coco_gt, coco_dt, 'bbox')
    coco_eval.evaluate()
    coco_eval.accumulate()
    coco_eval.summarize()
    return coco_eval.stats[0]  # mAP@0.5