# models/detector.py
import torch.nn as nn
from .backbone_resnet import ResNetBackbone
from .head_yolo import YOLOHead

class Detector(nn.Module):
    def __init__(self, num_classes):
        super(Detector, self).__init__()
        self.backbone = ResNetBackbone()
        self.head = YOLOHead(in_channels=128, num_classes=num_classes)

    def forward(self, x):
        x = self.backbone(x)
        x = self.head(x)
        return x