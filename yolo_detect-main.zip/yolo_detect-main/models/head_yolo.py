# models/head_yolo.py
import torch.nn as nn

class YOLOHead(nn.Module):
    def __init__(self, in_channels, num_classes):
        super(YOLOHead, self).__init__()
        self.conv = nn.Conv2d(in_channels, num_classes * (5 + num_classes), 1)

    def forward(self, x):
        return self.conv(x)