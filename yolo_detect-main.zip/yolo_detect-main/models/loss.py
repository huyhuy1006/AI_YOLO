# models/loss.py
import torch
import torch.nn as nn

class YOLOLoss(nn.Module):
    def __init__(self, num_classes, num_anchors=1):
        super(YOLOLoss, self).__init__()
        self.num_classes = num_classes
        self.num_anchors = num_anchors
        self.mse = nn.MSELoss()
        self.bce = nn.BCEWithLogitsLoss()

    def forward(self, pred, target):
        # Reshape pred: [batch_size, num_anchors * (5 + num_classes), H, W] -> [batch_size, num_anchors, H, W, 5 + num_classes]
        batch_size, _, H, W = pred.shape
        pred = pred.view(batch_size, self.num_anchors, 5 + self.num_classes, H, W).permute(0, 1, 3, 4, 2)
        coord_loss = self.mse(pred[..., :4], target[..., :4])
        conf_loss = self.bce(pred[..., 4], target[..., 4])
        cls_loss = self.bce(pred[..., 5:], target[..., 5:])
        return coord_loss + conf_loss + cls_loss