# datasets/transforms.py
import albumentations as A
import numpy as np

class YOLOTransforms:
    def __init__(self, img_size=416):
        self.transform = A.Compose([
            A.Resize(height=img_size, width=img_size, p=1.0),
            A.HorizontalFlip(p=0.5),
            A.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225), p=1.0),
        ], bbox_params=A.BboxParams(format='yolo', label_fields=['class_labels'], min_visibility=0.1))

    def __call__(self, img, boxes, labels):
        boxes = boxes if isinstance(boxes, list) else boxes.tolist()
        labels = labels if isinstance(labels, list) else labels.tolist()
        # Filter invalid boxes
        valid_boxes = []
        valid_labels = []
        for box, label in zip(boxes, labels):
            x_center, y_center, width, height = box
            if (0 <= x_center <= 1 and 0 <= y_center <= 1 and
                0 <= width <= 1 and 0 <= height <= 1 and
                x_center - width/2 >= 0 and x_center + width/2 <= 1 and
                y_center - height/2 >= 0 and y_center + height/2 <= 1):
                valid_boxes.append(box)
                valid_labels.append(label)
        transformed = self.transform(
            image=img,
            bboxes=valid_boxes,
            class_labels=valid_labels
        )
        return transformed['image'], np.array(transformed['bboxes']), np.array(transformed['class_labels'])