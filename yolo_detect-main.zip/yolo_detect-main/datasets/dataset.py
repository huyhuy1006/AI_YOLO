# datasets/dataset.py
import os
import cv2
import numpy as np
from torch.utils.data import Dataset

class YOLODataset(Dataset):
    def __init__(self, data_dir, data_config, transform=None):
        self.data_dir = data_dir
        self.transform = transform
        self.imgs = [f for f in os.listdir(data_dir) if f.endswith('.jpg')]
        self.label_dir = os.path.join(data_dir, 'labels')
        self.nc = data_config['nc']

    def __len__(self):
        return len(self.imgs)

    def __getitem__(self, idx):
        img_path = os.path.join(self.data_dir, self.imgs[idx])
        img = cv2.imread(img_path)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)  # Convert to RGB

        # Load YOLO annotations
        label_path = os.path.join(self.label_dir, self.imgs[idx].replace('.jpg', '.txt'))
        boxes = []
        labels = []
        if os.path.exists(label_path):
            with open(label_path, 'r') as f:
                for line in f.readlines():
                    class_id, x_center, y_center, width, height = map(float, line.strip().split())
                    boxes.append([x_center, y_center, width, height])
                    labels.append(int(class_id))

        # Apply transforms
        if self.transform:
            img, boxes, labels = self.transform(img, boxes, labels)
        else:
            boxes = np.array(boxes)
            labels = np.array(labels)

        return img, boxes, labels