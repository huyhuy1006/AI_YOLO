import pandas as pd
import os
from PIL import Image
import numpy as np

def csv_to_yolo(csv_file, train_dir, val_dir, train_label_dir, val_label_dir):
    df = pd.read_csv(csv_file)
    os.makedirs(train_label_dir, exist_ok=True)
    os.makedirs(val_label_dir, exist_ok=True)

    for img_name in set(df['image']):
        train_img_path = os.path.join(train_dir, img_name)
        val_img_path = os.path.join(val_dir, img_name)
        
        if os.path.exists(train_img_path):
            img_path = train_img_path
            label_dir = train_label_dir
        elif os.path.exists(val_img_path):
            img_path = val_img_path
            label_dir = val_label_dir
        else:
            print(f"Image not found: {img_name}")
            continue

        try:
            img = Image.open(img_path)
            img_width, img_height = img.size
        except Exception as e:
            print(f"Error loading image {img_name}: {e}")
            continue

        img_rows = df[df['image'] == img_name]
        txt_path = os.path.join(label_dir, img_name.replace('.jpg', '.txt'))
        
        with open(txt_path, 'w') as f:
            for _, row in img_rows.iterrows():
                x_min, y_min, x_max, y_max = row['xmin'], row['ymin'], row['xmax'], row['ymax']
                # Clamp input coordinates
                x_min = max(0, x_min)
                y_min = max(0, y_min)
                x_max = min(img_width, x_max)
                y_max = min(img_height, y_max)
                # Calculate YOLO format
                x_center = (x_min + x_max) / 2 / img_width
                y_center = (y_min + y_max) / 2 / img_height
                width = (x_max - x_min) / img_width
                height = (y_max - y_min) / img_height
                # Clamp YOLO coordinates
                x_center = np.clip(x_center, 0.0, 1.0)
                y_center = np.clip(y_center, 0.0, 1.0)
                width = np.clip(width, 0.0, 1.0)
                height = np.clip(height, 0.0, 1.0)
                class_id = 0  # Single class ("car")
                f.write(f"{class_id} {x_center:.6f} {y_center:.6f} {width:.6f} {height:.6f}\n")

# Usage
csv_to_yolo(
    csv_file='archive/data/train_solution_bounding_boxes (1).csv',
    train_dir='data/train',
    val_dir='data/val',
    train_label_dir='data/train/labels',
    val_label_dir='data/val/labels'
)