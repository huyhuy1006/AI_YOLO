# tests/test_training.py
import unittest
from training.trainer import Trainer

class TestTraining(unittest.TestCase):
    def test_trainer_init(self):
        model_config = {'nc': 1}
        data_config = {'train': 'data/train', 'val': 'data/val', 'nc': 1}
        train_config = {'lr': 0.001, 'batch_size': 4, 'img_size': 416}
        trainer = Trainer(model_config, data_config, train_config)
        self.assertIsNotNone(trainer.model)

if __name__ == '__main__':
    unittest.main()