# tests/test_dataset.py
import unittest
from datasets.dataset import YOLODataset

class TestDataset(unittest.TestCase):
    def test_dataset_loading(self):
        dataset = YOLODataset('data/train', 'data/labels/train')
        img, boxes = dataset[0]
        self.assertEqual(img.shape[0], 3)  # Kiểm tra số kênh ảnh
        self.assertTrue(len(boxes) >= 0)  # Kiểm tra nhãn

if __name__ == '__main__':
    unittest.main()