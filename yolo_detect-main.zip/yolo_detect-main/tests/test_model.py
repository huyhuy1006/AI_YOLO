# tests/test_model.py
import unittest
import torch
from models.detector import Detector

class TestModel(unittest.TestCase):
    def test_model_forward(self):
        model = Detector(num_classes=1)
        x = torch.randn(1, 3, 416, 416)
        out = model(x)
        self.assertEqual(out.shape[1], 1 * (5 + 1))  # Kiểm tra kích thước đầu ra

if __name__ == '__main__':
    unittest.main()